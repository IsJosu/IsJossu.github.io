var audio = document.getElementById("click");

function PlayAudio() {

	audio.play();
	document.getElementById("img").classList.add("girar");

	setTimeout(function() {

		document.getElementById("titulo").classList.add("tranparencia_titulo");


	}, 1000);

	// document.getElementById("titulo").classList.add("a");
	setInterval(function(){

		document.getElementById("titulo").classList.add("a");

	}, 1000);

	setTimeout(function() {

		document.getElementById("textoA").classList.add("textoA1");


	}, 2300);
	setTimeout(function() {

		document.getElementById("textoB").classList.add("textoB1");


	}, 8100);
	setTimeout(function() {

		document.getElementById("textoC").classList.add("textoC1");


	}, 13500);
	setTimeout(function() {

		document.getElementById("textoD").classList.add("textoD1");


	}, 18800);
	setTimeout(function() {

		document.getElementById("img2").classList.add("texto1_imagen_mod");


	}, 10000);

	setInterval(function(){

		document.getElementById("ctnr").classList.add("desvan");

	}, 24000);
	setInterval(function(){

		document.getElementById("img2").classList.add("desvan");


	}, 30000);

	setTimeout(function() {

		document.getElementById("texto2").classList.add("b");


	}, 24200);
	setInterval(function(){

		document.getElementById("texto2").classList.remove("b");


	}, 35000);
	setTimeout(function() {

		document.getElementById("texto_A").classList.add("texto_A1");


	}, 47200);
	setTimeout(function() {

		document.getElementById("texto_B").classList.add("texto_B1");


	}, 52000);
	setTimeout(function() {

		document.getElementById("texto_C").classList.add("texto_C1");


	}, 54800);
	setTimeout(function() {

		document.getElementById("texto_D").classList.add("texto_D1");


	}, 57000);
	setTimeout(function() {

		document.getElementById("texto_E").classList.add("texto_E1");


	}, 60000);
	setTimeout(function() {

		document.getElementById("texto_F").classList.add("texto_F1");


	}, 61200);
	setInterval(function(){

		document.getElementById("ctnr2").classList.add("desvan");

	}, 68200);

	setTimeout(function() {

		document.getElementById("texto_A_A").classList.add("texto_A_A1");


	}, 68200);
	setTimeout(function() {

		document.getElementById("texto_B_B").classList.add("texto_B_B1");


	}, 73500);
	setTimeout(function() {

		document.getElementById("texto_C_C").classList.add("texto_C_C1");


	}, 77000);
	setTimeout(function() {

		document.getElementById("texto_D_D").classList.add("texto_D_D1");


	}, 79000);
	setTimeout(function() {

		document.getElementById("texto_E_E").classList.add("texto_E_E1");


	}, 84000);
	setTimeout(function() {

		document.getElementById("texto_F_F").classList.add("texto_F_F1");


	}, 87000);
	setInterval(function(){

		document.getElementById("ctnr3").classList.add("desvan");

	}, 89000);

	setTimeout(function() {

		document.getElementById("texto_uno").classList.add("texto_uno1");


	}, 89200);
	setTimeout(function() {

		document.getElementById("texto_dos").classList.add("texto_dos1");


	}, 93200);
	setTimeout(function() {

		document.getElementById("texto_tres").classList.add("texto_tres1");


	}, 98200);
	setTimeout(function() {

		document.getElementById("texto_cuatro").classList.add("texto_cuatro1");


	}, 102200);
	setTimeout(function() {

		document.getElementById("texto_cinco").classList.add("texto_cinco1");


	}, 105200);

	setInterval(function(){

		document.getElementById("ctnr4").classList.add("desvan");

	}, 112000);

	setTimeout(function() {

		document.getElementById("ag").classList.add("ag1");


	}, 122800);
	setTimeout(function() {

		document.getElementById("ar").classList.add("ar1");


	}, 127900);
	setTimeout(function() {

		document.getElementById("fu").classList.add("fu1");


	}, 133000);
	setTimeout(function() {

		document.getElementById("ti").classList.add("ti1");


	}, 139000);
	setInterval(function(){

		document.getElementById("ctnr5").classList.add("desvan");

	}, 145000);

	setTimeout(function() {

		document.getElementById("am").classList.add("am1");


	}, 145000);
	setTimeout(function() {

		document.getElementById("jh").classList.add("jh1");


	}, 150300);
	setTimeout(function() {

		document.getElementById("fer").classList.add("fer1");


	}, 153800);
	setTimeout(function() {

		document.getElementById("je").classList.add("je1");


	}, 155800);
	setTimeout(function() {

		document.getElementById("fa").classList.add("fa1");


	}, 160800);
	setTimeout(function() {

		document.getElementById("iv").classList.add("iv1");


	}, 163800);

	setInterval(function(){

		document.getElementById("ctnr6").classList.add("desvan");

	}, 166000);

	setTimeout(function() {

		document.getElementById("ctnr7").classList.add("c");


	}, 170000);
	



}



